import numpy as np
if __name__ == '__main__':
    old = ""
    new = ""
    i = 0
    with open('D:/yolov8/Intestinal Organoid Dataset/test_labels.csv', 'r+', encoding='utf-8') as filetxt:
        lines = filetxt.readlines()
        lineuses = ""
        filetxt.seek(0)
        for line in lines:
            line = line.strip('\n')
            tmp = "C:/Users/Timothy/Desktop/keras-retinanet/images/test/Subset_1_450x450_" + "{0:0>3}".format(str(i)) +".jpg,"
            i += 1
            old = tmp
            lineuses = lineuses + "".join(line).replace(old, new)
        filetxt.truncate()
        filetxt.write("".join(lineuses))
""""
在使用Python进行txt文件的读写时，当打开文件后，首先用read（）对文件的内容读取，然后再用write（）写入，这时发现虽然是用“r+”模式打开，按道理是应该覆盖的，但是却出现了追加的情况。
这是因为在使用read后，文档的指针已经指向了文本最后，而write写入的时候是以指针为起始，因此就产生了追加的效果。
如果想要覆盖，需要先seek（0），然后使用truncate()清除后，即可实现重新覆盖写入
"""
